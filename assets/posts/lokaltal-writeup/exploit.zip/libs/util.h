#ifndef UTIL_H
#define UTIL_H

// Windows-specific defines
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <windows.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <process.h>

#if defined(__x86_64__) || defined(__i386__) || defined(_M_X64) || defined(_M_IX86)
#define x86
#endif

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int8_t i8;
typedef int16_t i16;
typedef int32_t i32;
typedef int64_t i64;
typedef size_t sz;

/* Assert that x is true. */
#define CHK(x)                                                                 \
  do {                                                                         \
    if (!(x)) {                                                                \
      lerror("%s\n", "CHK(" #x ")");                                           \
    }                                                                          \
  } while (0)

/* Windows API call checker for handle returns */
#define HNDLCHK(x)                                                              \
  do {                                                                           \
    HANDLE __res = (x);                                                     \
    if (__res == 0 || __res == INVALID_HANDLE_VALUE) {                        \
      DWORD __err = GetLastError();                                            \
      lerror("%s: Error %lu (0x%08lx)", "HNDLCHK(" #x ")", __err, __err);       \
    }                                                                          \
  } while (0)

/* Windows API call checker for NTSTATUS returns */
#define STATUSCHK(x)                                                              \
  do {                                                                          \
    NTSTATUS __status = (x);                                                    \
    if (FAILED(__status)) {                                                    \
      lerror("%s: Error 0x%08lx", "STATUSCHK(" #x ")", __status);            \
    }                                                                       \
  } while (0)

/* Windows API call checker for boolean returns */
#define BOOLCHK(x)                                                              \
  do {                                                                         \
    if (!(x)) {                                                                \
      DWORD __err = GetLastError();                                            \
      lerror("%s: Error %lu (0x%08lx)", "BOOLCHK(" #x ")", __err, __err);       \
    }                                                                          \
  } while (0)

#ifdef x86

#define TIMER_RDTSC 1     // standard timestamp counter
#define TIMER_RDTSCP 2    // serializing timestamp counter
#define TIMER_RDPRU 3     // high-res timer on recent AMD

#define TIMER TIMER_RDTSC

#define RDPRU ".byte 0x0f, 0x01, 0xfd"
#define RDPRU_ECX_MPERF 0
#define RDPRU_ECX_APERF 1

uint64_t rdtsc();
void prefetch(void* p);
size_t flushandreload(void* addr);
void burn_cycles(unsigned long long cycles);
#endif

int ipow(int base, unsigned int power);
char* cyclic_gen(char* buf, int length);
char* cyclic(int length);
char* to_hex(char* dst, char* src, size_t size);

/* logging */
void print_hex(void* data, size_t size);

// Windows console color support
void enable_console_colors(void);

#define RED(x) "\033[31;1m" x "\033[0m"
#define GREEN(x) "\033[32;1m" x "\033[0m"
#define YELLOW(x) "\033[33;1m" x "\033[0m"
#define BLUE(x) "\033[34;1m" x "\033[0m"
#define MAGENTA(x) "\033[35;1m" x "\033[0m"

#define LINFO "[" BLUE("*") "] "
#define LDEBUG "[" GREEN("D") "] "
#define LWARN "[" YELLOW("!") "] "
#define LERROR "[" RED("-") "] "
#define LSTAGE "[" MAGENTA("STAGE: %d") "] "

#define linfo(format, ...) printf(LINFO format "\n", ##__VA_ARGS__)
#define lhex(x) linfo("0x%016llx <- %s", (uint64_t)x, #x)

#define lwarn(format, ...) fprintf(stderr, LWARN format "\n", ##__VA_ARGS__)

#define lerror(format, ...)                                                    \
  do {                                                                         \
    fprintf(stderr, LERROR format "\n", ##__VA_ARGS__);                        \
    while(1) Sleep(0);                                                        \
  } while (0)

extern int stage;
#define lstage(format, ...) printf(LSTAGE format "\n", ++stage, ##__VA_ARGS__)

#ifdef DEBUG
#define ldebug(format, ...) printf(LDEBUG format "\n", ##__VA_ARGS__)
#else
#define ldebug(...)
#endif

#endif