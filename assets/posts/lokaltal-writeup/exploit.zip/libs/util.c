#include "util.h"
#include <emmintrin.h>
#include <fcntl.h>
#include <intrin.h>
#include <io.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

int stage = 0;

uint64_t __forceinline rdtsc() {
#ifdef _M_X64
	// Use intrinsics for x64 builds (inline assembly not supported)
	_mm_mfence();
#if TIMER == TIMER_RDTSCP
	unsigned int aux;
	uint64_t result = __rdtscp(&aux);
#elif TIMER == TIMER_RDTSC
	uint64_t result = __rdtsc();
#else
	uint64_t result = __rdtsc();
#endif
	_mm_mfence();
	return result;
#else
	// Use inline assembly for x86 builds
	uint64_t a, d;
	__asm {
		mfence
	}
#if TIMER == TIMER_RDTSCP
	__asm { rdtscp mov dword ptr[a], eax mov dword ptr[d], edx }
#elif TIMER == TIMER_RDTSC
	__asm { rdtsc mov dword ptr[a], eax mov dword ptr[d], edx }
#else
	__asm { rdtsc mov dword ptr[a], eax mov dword ptr[d], edx }
#endif
	__asm {
		mfence
	}
	return (d << 32) | a;
#endif
}

void __forceinline prefetch(void* p) {
#ifdef _M_X64
	// Use intrinsics for x64 builds
	_mm_prefetch((const char*)p, _MM_HINT_T2);
#else
	// Use inline assembly for x86 builds
	__asm {
		mov eax, p
		_emit 0x0f
		_emit 0x18
		_emit 0x50 // prefetcht2 [eax]
	}
#endif
}

size_t flushandreload(void* addr) {
	size_t time = rdtsc();
	prefetch(addr);
	size_t delta = rdtsc() - time;
	return delta;
}

void burn_cycles(unsigned long long cycles) {
	unsigned long long start, ts;
	start = rdtsc();
	do {
		ts = rdtsc();
	} while ((ts - start) < cycles);
}

void pin_cpu(DWORD pid, int cpu) {
	HANDLE hProcess;
	DWORD_PTR processAffinityMask = 1ULL << cpu;

	if (pid == 0) {
		// Current process
		hProcess = GetCurrentProcess();
	}
	else {
		hProcess = OpenProcess(PROCESS_SET_INFORMATION, FALSE, pid);
		if (hProcess == NULL) {
			lerror("Failed to open process %lu for CPU pinning", pid);
			return;
		}
	}

	if (!SetProcessAffinityMask(hProcess, processAffinityMask)) {
		DWORD error = GetLastError();
		lerror("Failed to set process affinity: Error %lu", error);
	}

	if (pid != 0) {
		CloseHandle(hProcess);
	}
}

int ipow(int base, unsigned int power) {
	int out = 1;
	for (unsigned int i = 0; i < power; ++i) {
		out *= base;
	}
	return out;
}

char* cyclic_gen(char* buf, int length) {
	char charset[] = "abcdefghijklmnopqrstuvwxyz";
	int size = length;
	int charset_len = (int)strlen(charset);

	for (int i = 0; length > 0; ++i) {
		buf[size - length] = charset[i % charset_len];
		if (--length == 0)
			break;
		buf[size - length] = charset[(i / charset_len) % charset_len];
		if (--length == 0)
			break;
		buf[size - length] = charset[(i / ipow(charset_len, 2)) % charset_len];
		if (--length == 0)
			break;
		buf[size - length] = charset[(i / ipow(charset_len, 3)) % charset_len];
		--length;
	}
	buf[size] = 0;

	return buf;
}

char* cyclic(int length) {
	char* buf = (char*)calloc(length + 1, 1);
	if (buf == NULL) {
		lerror("Failed to allocate memory for cyclic pattern");
	}
	return cyclic_gen(buf, length);
}

char* to_hex(char* dst, char* src, size_t size) {
	for (size_t i = 0; i < size; ++i)
		sprintf_s(dst + i * 2, 3, "%02x", (unsigned char)src[i]);
	return dst;
}

void enable_console_colors(void) {
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	HANDLE hErr = GetStdHandle(STD_ERROR_HANDLE);
	DWORD dwMode = 0;

	// Enable ANSI escape sequences for colors
	if (hOut != INVALID_HANDLE_VALUE) {
		GetConsoleMode(hOut, &dwMode);
		dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
		SetConsoleMode(hOut, dwMode);
	}

	if (hErr != INVALID_HANDLE_VALUE) {
		GetConsoleMode(hErr, &dwMode);
		dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
		SetConsoleMode(hErr, dwMode);
	}
}

void print_hex(void* _data, size_t size) {
	unsigned char* data = (unsigned char*)_data;
	char ascii[17];
	size_t i, j, k;
	int skip = 0;
	ascii[16] = '\0';
	linfo("hexdump: ");

	for (i = 0; i < size; ++i) {
		if (i % 0x10 == 0) {
			memset(ascii, 0, sizeof(ascii));
			k = 0;
			if (i != 0 && memcmp(&data[i - 0x10], &data[i], 0x10) == 0) {
				i += 0xf;
				if (!skip)
					printf("*\n");
				skip = 1;
				continue;
			}
			else {
				skip = 0;
				printf("%08zx  ", i);
			}
		}

		if ((data[i] >= ' ') && (data[i] <= '~')) {
			k += sprintf_s(&ascii[k], sizeof(ascii) - k, GREEN("%c"), data[i]);
			printf(GREEN("%02x"), data[i]);
		}
		else {
			if (data[i] == 0xff) {
				printf(BLUE("%02x"), data[i]);
				k += sprintf_s(&ascii[k], sizeof(ascii) - k, BLUE("."));
			}
			else if (data[i] == 0) {
				printf("%02x", data[i]);
				k += sprintf_s(&ascii[k], sizeof(ascii) - k, ".");
			}
			else {
				printf(RED("%02x"), data[i]);
				k += sprintf_s(&ascii[k], sizeof(ascii) - k, RED("."));
			}
		}

		if (i % 2 == 1)
			putchar(' ');

		if ((i + 1) % 8 == 0 || i + 1 == size) {
			printf(" ");
			if ((i + 1) % 16 == 0) {
				printf(" %s \n", ascii);
			}
			else if (i + 1 == size) {
				if ((i + 1) % 16 <= 8) {
					printf(" ");
				}
				for (j = (i + 1) % 16; j < 16; ++j) {
					printf("  ");
					if (j % 2 == 1)
						putchar(' ');
				}
				printf(" %s \n", ascii);
			}
		}
	}
	printf("%08zx\n", i);
}