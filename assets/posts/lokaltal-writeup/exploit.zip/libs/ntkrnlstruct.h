#pragma once
#include <windef.h>
#include <winnt.h>

// taken from the amazing www.vergiliusproject.com <3

struct _EPROCESS;
struct _ALPC_PORT;
struct _ALPC_HANDLE_TABLE;
struct _KALPC_VIEW;

typedef struct _EX_PUSH_LOCK
{
	union
	{
		struct
		{
			ULONGLONG Locked : 1;                                             //0x0
			ULONGLONG Waiting : 1;                                            //0x0
			ULONGLONG Waking : 1;                                             //0x0
			ULONGLONG MultipleShared : 1;                                     //0x0
			ULONGLONG Shared : 60;                                            //0x0
		};
		ULONGLONG Value;                                                    //0x0
		VOID* Ptr;                                                          //0x0
	};
} EX_PUSH_LOCK;

typedef struct _POOL_HEADER
{
	union
	{
		struct
		{
			USHORT PreviousSize : 8;                                          //0x0
			USHORT PoolIndex : 8;                                             //0x0
			USHORT BlockSize : 8;                                             //0x2
			USHORT PoolType : 8;                                              //0x2
		};
		ULONG Ulong1;                                                       //0x0
	};
	ULONG PoolTag;                                                          //0x4
	union
	{
		struct _EPROCESS* ProcessBilled;                                    //0x8
		struct
		{
			USHORT AllocatorBackTraceIndex;                                 //0x8
			USHORT PoolTagHash;                                             //0xa
		};
	};
} POOL_HEADER;

// originally called BLOB on vergilus, but that struct is alerady defined in the public-facing API
typedef struct _KBLOB
{
	union
	{
		struct _LIST_ENTRY ResourceList;                                    //0x0
		struct _SLIST_ENTRY FreeListEntry;                                  //0x0
	};
	union
	{
		struct
		{
			UCHAR ReferenceCache : 1;                                         //0x10
			UCHAR Lookaside : 1;                                              //0x10
			UCHAR Initializing : 1;                                           //0x10
			UCHAR Deleted : 1;                                                //0x10
		} s1;                                                               //0x10
		UCHAR Flags;                                                        //0x10
	} u1;                                                                   //0x10
	UCHAR ResourceId;                                                       //0x11
	SHORT CachedReferences;                                                 //0x12
	LONGLONG ReferenceCount;                                                //0x18
	struct _EX_PUSH_LOCK Lock;                                              //0x20
} KBLOB;

typedef struct _KALPC_SECTION
{
	VOID* SectionObject;                                                    //0x0
	ULONGLONG Size;                                                         //0x8
	struct _ALPC_HANDLE_TABLE* HandleTable;                                 //0x10
	VOID* SectionHandle;                                                    //0x18
	struct _EPROCESS* OwnerProcess;                                         //0x20
	struct _ALPC_PORT* OwnerPort;                                           //0x28
	union
	{
		struct
		{
			ULONG Internal : 1;                                               //0x30
			ULONG Secure : 1;                                                 //0x30
		} s1;                                                               //0x30
	} u1;                                                                   //0x30
	ULONG NumberOfRegions;                                                  //0x34
	struct _LIST_ENTRY RegionListHead;                                      //0x38
} KALPC_SECTION;

typedef struct _KALPC_REGION
{
	struct _LIST_ENTRY RegionListEntry;                                     //0x0
	struct _KALPC_SECTION* Section;                                         //0x10
	ULONGLONG Offset;                                                       //0x18
	ULONGLONG Size;                                                         //0x20
	ULONGLONG ViewSize;                                                     //0x28
	union
	{
		struct
		{
			ULONG Secure : 1;                                                 //0x30
		} s1;                                                               //0x30
	} u1;                                                                   //0x30
	ULONG NumberOfViews;                                                    //0x34
	struct _LIST_ENTRY ViewListHead;                                        //0x38
	struct _KALPC_VIEW* ReadOnlyView;                                       //0x48
	struct _KALPC_VIEW* ReadWriteView;                                      //0x50
} KALPC_REGION;

typedef struct _KALPC_VIEW
{
	struct _LIST_ENTRY ViewListEntry;                                       //0x0
	struct _KALPC_REGION* Region;                                           //0x10
	struct _ALPC_PORT* OwnerPort;                                           //0x18
	struct _EPROCESS* OwnerProcess;                                         //0x20
	VOID* Address;                                                          //0x28
	ULONGLONG Size;                                                         //0x30
	VOID* SecureViewHandle;                                                 //0x38
	VOID* WriteAccessHandle;                                                //0x40
	union
	{
		struct
		{
			ULONG WriteAccess : 1;                                            //0x48
			ULONG AutoRelease : 1;                                            //0x48
			ULONG ForceUnlink : 1;                                            //0x48
			ULONG SystemSpace : 1;                                            //0x48
		} s1;                                                               //0x48
	} u1;                                                                   //0x48
	ULONG NumberOfOwnerMessages;                                            //0x4c
	struct _LIST_ENTRY ProcessViewListEntry;                                //0x50
} KALPC_VIEW;

typedef struct _WNF_STATE_DATA
{
	ULONG Header;															//0x0
	ULONG AllocatedSize;                                                    //0x4
	ULONG DataSize;                                                         //0x8
	ULONG ChangeStamp;                                                      //0xc
} WNF_STATE_DATA;

typedef struct _PROCESS_DISK_COUNTERS
{
	ULONGLONG BytesRead;                                                    //0x0
	ULONGLONG BytesWritten;                                                 //0x8
	ULONGLONG ReadOperationCount;                                           //0x10
	ULONGLONG WriteOperationCount;                                          //0x18
	ULONGLONG FlushOperationCount;                                          //0x20
} PROCESS_DISK_COUNTERS;