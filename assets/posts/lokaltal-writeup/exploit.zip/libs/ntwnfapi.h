#pragma once
#include <windef.h>
#include <winnt.h>

typedef struct _WNF_STATE_NAME {
	ULONG Data[2];
} WNF_STATE_NAME, * PWNF_STATE_NAME;

typedef enum _WNF_STATE_NAME_LIFETIME
{
	WnfWellKnownStateName,
	WnfPermanentStateName,
	WnfPersistentStateName,
	WnfTemporaryStateName
} WNF_STATE_NAME_LIFETIME;

typedef enum _WNF_DATA_SCOPE
{
	WnfDataScopeSystem,
	WnfDataScopeSession,
	WnfDataScopeUser,
	WnfDataScopeProcess,
	WnfDataScopeMachine
} WNF_DATA_SCOPE;

typedef struct _WNF_TYPE_ID
{
	GUID TypeId;
} WNF_TYPE_ID, * PWNF_TYPE_ID;

typedef const WNF_TYPE_ID* PCWNF_TYPE_ID;
typedef ULONG WNF_CHANGE_STAMP, * PWNF_CHANGE_STAMP;


NTSYSCALLAPI NTSTATUS NTAPI NtCreateWnfStateName(
	_Out_ PWNF_STATE_NAME StateName,
	_In_ WNF_STATE_NAME_LIFETIME NameLifetime,
	_In_ WNF_DATA_SCOPE DataScope,
	_In_ BOOLEAN PersistData,
	_In_opt_ PCWNF_TYPE_ID TypeId,
	_In_ ULONG MaximumStateSize,
	_In_ PSECURITY_DESCRIPTOR SecurityDescriptor
);

NTSYSCALLAPI NTSTATUS NTAPI NtUpdateWnfStateData(
	_In_ PWNF_STATE_NAME StateName,
	_In_reads_bytes_opt_(Length) const VOID* Buffer,
	_In_opt_ ULONG Length,
	_In_opt_ PCWNF_TYPE_ID TypeId,
	_In_opt_ PVOID ExplicitScope,
	_In_ WNF_CHANGE_STAMP MatchingChangeStamp,
	_In_ BOOL CheckStamp
);

NTSYSCALLAPI NTSTATUS NTAPI NtDeleteWnfStateName(
	_In_ PWNF_STATE_NAME StateName
);

NTSYSCALLAPI NTSTATUS NTAPI NtDeleteWnfStateData(
	_In_ PWNF_STATE_NAME StateName,
	_In_opt_ PVOID ExplicitScope
);

NTSYSCALLAPI NTSTATUS NTAPI NtQueryWnfStateData(
	_In_ PWNF_STATE_NAME StateName,
	_In_opt_ PCWNF_TYPE_ID TypeId,
	_In_opt_ PVOID ExplicitScope,
	_Out_ PWNF_CHANGE_STAMP ChangeStamp,
	_Out_writes_bytes_opt_(*BufferLength) PVOID Buffer,
	_Inout_ PULONG BufferLength
);